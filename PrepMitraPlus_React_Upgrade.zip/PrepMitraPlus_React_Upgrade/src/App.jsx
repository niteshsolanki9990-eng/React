import React from 'react';

// React entry point. The original website is preserved intact during this first migration stage.
export default function App() {
  return (
    <main className="site-frame" aria-label="PrepMitraPlus website">
      <iframe
        className="legacy-site"
        src="/legacy-version.html"
        title="PrepMitraPlus original website"
        loading="eager"
      />
    </main>
  );
}
