# PrepMitraPlus React (पहला migration चरण)

इस प्रोजेक्ट में मूल `Niteshoverthinkar.html` को `public/legacy-version.html` में बिना बदलाव सुरक्षित रखा गया है। React/Vite ऐप उसे iframe में दिखाता है ताकि मौजूदा डिजाइन और पुराने JavaScript फीचर इस शुरुआती चरण में वैसे ही रहें।

## GitHub Codespaces में चलाएँ

1. ZIP को extract करें।
2. इस फ़ोल्डर के अंदर की सभी फाइलें GitHub repository में upload करें (ZIP को अकेले upload न करें)।
3. Repository में Code → Codespaces → Create codespace खोलें।
4. Terminal में चलाएँ:

```bash
npm install
npm run dev
```

5. Codespaces में Port 5173 का Preview खोलें।

## अभी React से क्या बदला है?
- React app entry point और component structure जुड़ा है।
- Vite development server से project चलता है।
- मूल वेबसाइट का HTML/CSS/JS सुरक्षित है, इसलिए वर्तमान रूप और मौजूदा demo व्यवहार बनाए रखने का लक्ष्य है।

## ईमानदार सीमा
यह अभी पूर्ण React rewrite नहीं है। मौजूदा वेबसाइट iframe के अंदर मूल HTML के रूप में चलती है। अगली migration में एक-एक करके Header, Home, cards, navigation, pages, reviews और Admin UI को वास्तविक React components में बदला जाएगा। Backend, secure login, shared database, analytics और payment इस पैकेज में शामिल नहीं हैं।
